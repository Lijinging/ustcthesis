#!/bin/sh
# this is for Unix/Linux clean scripts
rm -f  *.aux
rm -f  chapter/*.aux
rm -f *.log
rm -f *.lof
rm -f *.lot
rm -f *.bbl
rm -f *.blg
rm -f *.thm
rm -f *.toc
rm -f *.out
rm -f *.loa
